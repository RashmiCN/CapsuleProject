import { ChildTaskFilterPipe } from './child-task-filter.pipe';

describe('ChildTaskFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ChildTaskFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
