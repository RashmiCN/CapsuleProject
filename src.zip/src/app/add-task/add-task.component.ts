import { Component, OnInit, Input } from '@angular/core';
import { ITask } from './Task';
import { ActivatedRoute , Router} from '@angular/router';
import { TaskService } from '../task.service';
import { DataService } from '../data.service';


@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {
  @Input() task = {
      taskName: '',
      priority: 0,
      parentTaskName: '',
      startDate: new Date(),
      endDate: new Date()
    };

  reload = 'Reload';
  constructor(private taskService: TaskService, private router: Router, private data: DataService) {}
  // All process to be performed on init
  ngOnInit() {
  }

  // all the functions to be performed on add
  addFunctions() {
    this.addTask();
    this.pushToView("Refresh");
  }

  // add task to DB
  addTask() {
    console.log(this.task);
    this.taskService.addTask(this.task).subscribe((task) => {}, (err) => {
      console.log(err);
    });
  }

  // Reset values
  resetTask() {
    this.task = {
      taskName: '',
      priority: 0,
      parentTaskName: '',
      startDate: null,
      endDate: null
    };
  }

  // Push refresh request to view
  pushToView(view:string) {
    console.log('pushing refesh request to service');
    this.data.changeReloadMessage(view);
  }
}
