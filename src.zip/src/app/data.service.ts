import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ITask } from './add-task/Task';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  
  task : ITask = {
    taskName: '',
    priority: 0,
    parentTaskName: '',
    startDate: new Date(),
    endDate: new Date()
  };

  reloadMsg: string = "noReload";

  // this is communication between edit task and view task
  private messageSource = new BehaviorSubject<ITask>(this.task);
  currentMessage = this.messageSource.asObservable();

  // this is communication between add task and view task
  private messageReloadSource = new BehaviorSubject<string>(this.reloadMsg);
  currentReloadMessage = this.messageReloadSource.asObservable();

  constructor() { }
  // this is communication between edit task and view task
  changeMessage(message: ITask) {
    console.log(message);
    this.messageSource.next(message)
  }

  // this is communication between add task and view task
  changeReloadMessage(reloadMsg) {
    console.log('changed reload message::' + reloadMsg);
    this.messageSource.next(reloadMsg)
  }
}
