package com.capsule.TaskTracker.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capsule.TaskTracker.entity.Task;
import com.capsule.TaskTracker.jdbc.TaskDAO;
//import com.tasktracker.jdbc.TaskDao;

@Repository
public class TaskRepository {

	@Autowired
	private TaskDAO taskDao;
	
	public List<Task> getTaskList() {
		System.out.println("TaskListRepo");
		return taskDao.getTaskList();
	}

	public boolean createTask(Task Task) {
		return taskDao.insertTask(Task);
	}

	public Task getTask(int TaskId) {
		return taskDao.getTask(TaskId);
	}

	public boolean deleteTask(int TaskId) {
		return taskDao.deleteTask(TaskId);
	}

//	public boolean updateTask(int TaskId, Task Task) {
//		return taskDao.updateTask(TaskId, Task.getName());
//	}
	
	/*public static void main(String[] args) {
		TaskRepository pr = new TaskRepository();
		System.out.println(pr.getTaskDb());
	}*/
}
